-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2024 at 10:15 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendancesystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`) VALUES
(1, 'admin', 'me', 'admin@mail.com', 'Password@123'),
(2, 'hod', 'hodteacher', 'hod@gmail.com', 'hod@123');

-- --------------------------------------------------------

--
-- Table structure for table `tblattendance`
--

CREATE TABLE `tblattendance` (
  `Id` int(10) NOT NULL,
  `admissionNo` varchar(255) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `sessionTermId` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dateTimeTaken` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblattendance`
--

INSERT INTO `tblattendance` (`Id`, `admissionNo`, `classId`, `classArmId`, `sessionTermId`, `status`, `dateTimeTaken`) VALUES
(1, '2169381242528`', '2', '1', '7', '1', '2024-05-26'),
(2, '2169381242522', '2', '1', '7', '1', '2024-05-26'),
(3, '2169381242515', '2', '2', '7', '1', '2024-05-26'),
(4, '2169381242528`', '2', '1', '7', '1', '2024-05-16'),
(5, '2169381242522', '2', '1', '7', '1', '2024-05-16'),
(6, '2169381242528`', '2', '1', '7', '1', '2024-05-23'),
(7, '2169381242522', '2', '1', '7', '1', '2024-05-23'),
(8, '2169381242528`', '2', '1', '7', '1', '2024-05-27'),
(9, '2169381242522', '2', '1', '7', '1', '2024-05-27'),
(10, '2169381242528`', '2', '1', '7', '1', '2024-05-24'),
(11, '2169381242522', '2', '1', '7', '1', '2024-05-24'),
(12, '2169381242528`', '2', '1', '7', '0', '2024-05-17'),
(13, '2169381242522', '2', '1', '7', '0', '2024-05-17'),
(14, '2169381242528`', '2', '1', '7', '0', '2024-05-02'),
(15, '2169381242522', '2', '1', '7', '0', '2024-05-02'),
(16, '2169381242528`', '2', '1', '7', '1', '2024-05-28'),
(17, '2169381242522', '2', '1', '7', '1', '2024-05-28'),
(18, '2169381242528`', '2', '1', '7', '0', '2024-06-01'),
(19, '2169381242522', '2', '1', '7', '0', '2024-06-01'),
(20, '2169381242528`', '2', '1', '7', '0', '2024-06-05'),
(21, '2169381242522', '2', '1', '7', '0', '2024-06-05'),
(22, '2169381242528`', '2', '1', '7', '1', '2024-05-05'),
(23, '2169381242522', '2', '1', '7', '1', '2024-05-05'),
(24, '2169381242515', '2', '2', '7', '1', '2024-05-28'),
(25, '2169381242515', '2', '2', '7', '1', '2024-05-27'),
(26, '2169381242515', '2', '2', '7', '1', '2024-05-29'),
(27, '2169381242528`', '2', '1', '7', '0', '2024-05-29'),
(28, '2169381242522', '2', '1', '7', '0', '2024-05-29'),
(29, '2169381242528`', '2', '1', '7', '0', '2024-05-30'),
(30, '2169381242522', '2', '1', '7', '0', '2024-05-30');

-- --------------------------------------------------------

--
-- Table structure for table `tblclass`
--

CREATE TABLE `tblclass` (
  `Id` int(10) NOT NULL,
  `className` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclass`
--

INSERT INTO `tblclass` (`Id`, `className`) VALUES
(2, 'CSE'),
(3, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassarms`
--

CREATE TABLE `tblclassarms` (
  `Id` int(10) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmName` varchar(255) NOT NULL,
  `isAssigned` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclassarms`
--

INSERT INTO `tblclassarms` (`Id`, `classId`, `classArmName`, `isAssigned`) VALUES
(1, '2', 'Class-1', '1'),
(2, '2', 'Class-2', '1'),
(3, '3', 'Class-1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassteacher`
--

CREATE TABLE `tblclassteacher` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phoneNo` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclassteacher`
--

INSERT INTO `tblclassteacher` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`, `phoneNo`, `classId`, `classArmId`, `dateCreated`) VALUES
(1, 'Dheeraj', 'Lokhande', 'dblokhande@sswcoe.edu.in', 'pass123', '5868769876', '2', '1', '2024-05-26'),
(2, 'Geeta', 'Kulkarni', 'gkulkarni@sswcoe.edu.in', 'pass123', '1234567892', '2', '2', '2024-05-26'),
(3, 'Vinay', 'Shirshyad', 'vshirshyad@sswcoe.edu.in', 'pass123', '6839809876', '3', '3', '2024-05-26');

-- --------------------------------------------------------

--
-- Table structure for table `tblmarks`
--

CREATE TABLE `tblmarks` (
  `studentId` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `unitTest1` int(11) NOT NULL,
  `unitTest2` int(11) NOT NULL,
  `midSemExam` int(11) NOT NULL,
  `totalMarks` int(11) NOT NULL,
  `percentage` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblmarks`
--

INSERT INTO `tblmarks` (`studentId`, `firstName`, `lastName`, `unitTest1`, `unitTest2`, `midSemExam`, `totalMarks`, `percentage`) VALUES
(1, 'Pravalika', 'Manchikatala', 18, 19, 20, 37, 92),
(3, 'Rajeshwari ', 'Annam', 19, 20, 20, 39, 97),
(7, 'Tejaswini ', 'Mirajkar', 19, 20, 20, 39, 97),
(9, 'Anjali ', 'Late', 17, 18, 19, 35, 87),
(10, 'Sushama', 'Awale', 16, 16, 16, 32, 80);

-- --------------------------------------------------------

--
-- Table structure for table `tblpracattendance`
--

CREATE TABLE `tblpracattendance` (
  `Id` int(10) NOT NULL,
  `admissionNo` varchar(255) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `sessionTermId` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dateTimeTaken` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpracattendance`
--

INSERT INTO `tblpracattendance` (`Id`, `admissionNo`, `classId`, `classArmId`, `sessionTermId`, `status`, `dateTimeTaken`) VALUES
(0, '2169381242528`', '2', '1', '7', '1', '2024-05-29'),
(0, '2169381242522', '2', '1', '7', '1', '2024-05-29'),
(0, '2169381242528`', '2', '1', '7', '1', '2024-05-30'),
(0, '2169381242522', '2', '1', '7', '1', '2024-05-30');

-- --------------------------------------------------------

--
-- Table structure for table `tblsessionterm`
--

CREATE TABLE `tblsessionterm` (
  `Id` int(10) NOT NULL,
  `sessionName` varchar(50) NOT NULL,
  `termId` varchar(50) NOT NULL,
  `isActive` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblsessionterm`
--

INSERT INTO `tblsessionterm` (`Id`, `sessionName`, `termId`, `isActive`, `dateCreated`) VALUES
(7, '2023/2024', '1', '1', '2024-05-26'),
(6, '2019/2020', '', '0', '2024-05-26'),
(5, '2023/2024', '', '0', '2024-05-26'),
(9, '2022/2023', '1', '0', '2024-05-26');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `otherName` varchar(255) NOT NULL,
  `admissionNumber` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`Id`, `firstName`, `lastName`, `otherName`, `admissionNumber`, `password`, `classId`, `classArmId`, `dateCreated`) VALUES
(1, 'Pravalika', 'Manchikatala', 'none', '2169381242528`', '12345', '2', '1', '2024-05-26'),
(2, 'Akanksha', 'Yelgeti', 'none', '2169381242515', '12345', '2', '2', '2024-05-26'),
(3, 'Rajeshwari ', 'Annam', 'none', '2169381242522', '12345', '2', '1', '2024-05-26'),
(4, 'Dhanashri', 'Asade', 'none', '2169381242543', '12345', '3', '3', '2024-05-26'),
(5, 'Rani ', 'Vitkar', 'none', '2169381242527', '12345', '2', '2', '2024-05-30'),
(6, 'Yogita ', 'Uttur', '', '2169381242526', '12345', '2', '2', '2024-05-30'),
(7, 'Tejaswini ', 'Mirajkar', 'none', '2169381242523', '12345', '2', '1', '2024-05-30'),
(8, 'Ushashri ', 'Annam', 'none', '2169381242520', '12345', '2', '2', '2024-05-30'),
(9, 'Anjali ', 'Late', 'none', '2169381242521', '12345', '2', '1', '2024-05-30'),
(10, 'Sushama', 'Awale', 'none', '2169381242590', '12345', '2', '1', '2024-05-30'),
(11, 'Uma', 'Yerjal', 'none', '2169381242534', '12345', '2', '2', '2024-05-30'),
(12, 'Aishwarya ', 'Annam', 'none', '216938124267', '12345', '2', '2', '2024-05-30');

-- --------------------------------------------------------

--
-- Table structure for table `tblterm`
--

CREATE TABLE `tblterm` (
  `Id` int(10) NOT NULL,
  `termName` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblterm`
--

INSERT INTO `tblterm` (`Id`, `termName`) VALUES
(1, 'First'),
(2, 'Second');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblattendance`
--
ALTER TABLE `tblattendance`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclass`
--
ALTER TABLE `tblclass`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclassarms`
--
ALTER TABLE `tblclassarms`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclassteacher`
--
ALTER TABLE `tblclassteacher`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblsessionterm`
--
ALTER TABLE `tblsessionterm`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblterm`
--
ALTER TABLE `tblterm`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblattendance`
--
ALTER TABLE `tblattendance`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tblclass`
--
ALTER TABLE `tblclass`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblclassarms`
--
ALTER TABLE `tblclassarms`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblclassteacher`
--
ALTER TABLE `tblclassteacher`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblsessionterm`
--
ALTER TABLE `tblsessionterm`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblterm`
--
ALTER TABLE `tblterm`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
