<?php 
error_reporting(0);
include '../Includes/dbcon.php';
include '../Includes/session.php';

// Check if the view or export button is clicked
if(isset($_POST['view']) || isset($_POST['export'])) {
    // Get the start date and end date from the form
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Your existing query with the date range condition
    $query = "SELECT tblattendance.Id, tblattendance.status, tblattendance.dateTimeTaken, tblclass.className,
              tblclassarms.classArmName, tblsessionterm.sessionName, tblsessionterm.termId, tblterm.termName,
              tblstudents.firstName, tblstudents.lastName, tblstudents.otherName, tblstudents.admissionNumber
              FROM tblattendance
              INNER JOIN tblclass ON tblclass.Id = tblattendance.classId
              INNER JOIN tblclassarms ON tblclassarms.Id = tblattendance.classArmId
              INNER JOIN tblsessionterm ON tblsessionterm.Id = tblattendance.sessionTermId
              INNER JOIN tblterm ON tblterm.Id = tblsessionterm.termId
              INNER JOIN tblstudents ON tblstudents.admissionNumber = tblattendance.admissionNo
              WHERE tblattendance.classArmId = '$_SESSION[classArmId]'
              AND tblattendance.dateTimeTaken BETWEEN '$start_date' AND '$end_date'
              ORDER BY tblattendance.dateTimeTaken ASC";

    // Execute the query
    $ret = mysqli_query($conn, $query);

    // Check if the export button was clicked
    if(isset($_POST['export'])) {
        // Start output buffering to capture the Excel data
        ob_start();

        // Create Excel file content
        echo '<table border="1">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Other Name</th>
                          <th>Admission No</th>
                          <th>Class</th>
                          <th>Class Arm</th>
                          <th>Session</th>
                          <th>Term</th>
                          <th>Status</th>
                          <th>Date</th>
                      </tr>
                  </thead>
                  <tbody>';

        // Counter for row numbers
        $cnt = 1;

        // Loop through each row of the result set
        while ($row = mysqli_fetch_array($ret)) {
            // Determine status and color
            $status = ($row['status'] == '1') ? "Present" : "Absent";
            $colour = ($row['status'] == '1') ? "#00FF00" : "#FF0000";

            // Output row data
            echo '<tr>
                    <td>'.$cnt.'</td> 
                    <td>'.$row['firstName'].'</td> 
                    <td>'.$row['lastName'].'</td> 
                    <td>'.$row['otherName'].'</td> 
                    <td>'.$row['admissionNumber'].'</td> 
                    <td>'.$row['className'].'</td> 
                    <td>'.$row['classArmName'].'</td>
                    <td>'.$row['sessionName'].'</td>
                    <td>'.$row['termName'].'</td>
                    <td style="background-color: '.$colour.'">'.$status.'</td>
                    <td>'.$row['dateTimeTaken'].'</td>
                  </tr>';
            $cnt++;
        }

        // End Excel file content
        echo '</tbody></table>';

        // Get the Excel data from the output buffer
        $xlsData = ob_get_clean();

        // Set the headers for downloading the Excel file
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=attendance_report.xls");

        // Output the Excel data
        echo $xlsData;

        // Stop execution
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/sswcoe.jpg" rel="icon">
  <title>Dashboard</title>
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">

</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
      <?php include "Includes/sidebar.php";?>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
       <?php include "Includes/topbar.php";?>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">View Student Attendance</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">View Student Attendance</li>
            </ol>
          </div>

          <div class="row">
            <div class="col-lg-12">
              <!-- Form Basic -->
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">View Student Attendance</h6>
                </div>
                <div class="card-body">
                  <form method="post" action="">
                    <div class="form-group row mb-3">
                        <div class="col-xl-6">
                        <label class="form-control-label">Start Date<span class="text-danger ml-2">*</span></label>
                        <input type="date" name="start_date" class="form-control mb-3" value="<?php echo isset($_POST['start_date']) ? $_POST['start_date'] : ''; ?>" required>
                        </div>
                        <div class="col-xl-6">
                        <label class="form-control-label">End Date<span class="text-danger ml-2">*</span></label>
                        <input type="date" name="end_date" class="form-control mb-3" value="<?php echo isset($_POST['end_date']) ? $_POST['end_date'] : ''; ?>" required>
                        </div>
                    </div>
                    <button type="submit" name="view" class="btn btn-primary" style="background-color:#ffa427;">View Attendance</button>
                    <button type="submit" name="export" class="btn btn-success">Export to Excel</button>
                  </form>
                </div>
              </div>

              <!-- Attendance Table -->
              <?php if(isset($ret)) : ?>
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Attendance Table</h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Other Name</th>
                          <th>Admission No</th>
                          <th>Class</th>
                          <th>Class Arm</th>
                          <th>Session</th>
                          <th>Term</th>
                          <th>Status</th>
                          <th>Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                        $cnt = 1;
                        while ($row = mysqli_fetch_array($ret)) {
                            $status = ($row['status'] == '1') ? "Present" : "Absent";
                            $colour = ($row['status'] == '1') ? "#00FF00" : "#FF0000";
                            echo '<tr>
                                    <td>'.$cnt.'</td> 
                                    <td>'.$row['firstName'].'</td> 
                                    <td>'.$row['lastName'].'</td> 
                                    <td>'.$row['otherName'].'</td> 
                                    <td>'.$row['admissionNumber'].'</td> 
                                    <td>'.$row['className'].'</td> 
                                    <td>'.$row['classArmName'].'</td>
                                    <td>'.$row['sessionName'].'</td>
                                    <td>'.$row['termName'].'</td>
                                    <td style="background-color: '.$colour.'">'.$status.'</td>
                                    <td>'.$row['dateTimeTaken'].'</td>
                                  </tr>';
                            $cnt++;
                        }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <?php endif; ?>
            </div>
          </div>
          <!--Row-->
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
       <?php include "Includes/footer.php";?>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
    <!-- Logout Modal-->
    <?php include "Includes/logout_modal.php";?>
  
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <script src="../vendor/chart.js/Chart.min.js"></script>
  <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="js/demo/datatables-demo.js"></script>
</body>

</html>
